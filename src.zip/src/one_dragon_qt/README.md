# resource打包

在 _rc 目录先运行

```shell
pyside6-rcc resource.qrc -o resource.py
```