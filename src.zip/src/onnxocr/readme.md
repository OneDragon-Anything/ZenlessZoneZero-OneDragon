# 说明

复制自 https://github.com/jingsongliujing/OnnxOCR

更新时间 2025.06.05

改动说明

- 将模型、字体、文本放入 assets/models/onnx_ocr 中
