APP_ID="shiyu_defense"
APP_NAME="式舆防卫战"
NEED_NOTIFY=True
