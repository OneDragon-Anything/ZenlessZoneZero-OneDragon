APP_ID="random_play"
APP_NAME="录像店营业"
NEED_NOTIFY=True
