APP_ID = "coffee"
APP_NAME = "咖啡店"
NEED_NOTIFY = True
