APP_ID="withered_domain"
APP_NAME="枯萎之都"
NEED_NOTIFY=True
