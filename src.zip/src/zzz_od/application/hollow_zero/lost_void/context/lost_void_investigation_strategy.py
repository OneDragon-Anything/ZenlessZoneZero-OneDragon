class LostVoidInvestigationStrategy:

    def __init__(self,
                 strategy_name: str):
        self.strategy_name: str = strategy_name
