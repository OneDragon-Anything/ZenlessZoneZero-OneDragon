class LostVoidDetClass:

    def __init__(self, class_idx: int, class_name: str):
        self.class_idx: int = class_idx
        self.class_name: str = class_name