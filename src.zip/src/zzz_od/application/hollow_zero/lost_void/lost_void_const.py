APP_ID="lost_void"
APP_NAME="迷失之地"
NEED_NOTIFY=True
