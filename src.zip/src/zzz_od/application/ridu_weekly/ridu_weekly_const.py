APP_ID="ridu_weekly"
APP_NAME="丽都周纪 (领奖励)"
NEED_NOTIFY=True
