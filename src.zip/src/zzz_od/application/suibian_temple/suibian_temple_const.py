APP_ID="suibian_temple"
APP_NAME="随便观"
NEED_NOTIFY=True
