APP_ID="scratch_card"
APP_NAME="刮刮卡"
NEED_NOTIFY=True
