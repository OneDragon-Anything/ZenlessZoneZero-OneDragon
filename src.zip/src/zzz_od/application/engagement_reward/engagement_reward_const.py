APP_ID="engagement_reward"
APP_NAME="活跃度奖励"
NEED_NOTIFY=True
