APP_ID="commission_assistant"
APP_NAME="委托助手"