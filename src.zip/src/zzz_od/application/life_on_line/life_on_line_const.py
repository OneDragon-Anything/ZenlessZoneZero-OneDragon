APP_ID="life_on_line"
APP_NAME="真·拿命验收"
NEED_NOTIFY=True
