APP_ID="redemption_code"
APP_NAME="兑换码"
NEED_NOTIFY=True
