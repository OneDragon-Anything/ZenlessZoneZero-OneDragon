APP_ID="trigrams_collection"
APP_NAME="卦象集录"
NEED_NOTIFY=True
