APP_ID="drive_disc_dismantle"
APP_NAME="驱动盘拆解"
NEED_NOTIFY=True
