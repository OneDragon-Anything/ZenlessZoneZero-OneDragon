APP_ID='city_fund'
APP_NAME='丽都城募'
NEED_NOTIFY=True
