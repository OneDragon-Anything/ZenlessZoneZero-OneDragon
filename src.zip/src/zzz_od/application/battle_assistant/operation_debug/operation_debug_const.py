APP_ID="operation_debug"
APP_NAME="指令调试"