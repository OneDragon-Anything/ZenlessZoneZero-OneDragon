APP_ID="auto_battle"
APP_NAME="自动战斗"