APP_ID="dodge_assistant"
APP_NAME="闪避助手"