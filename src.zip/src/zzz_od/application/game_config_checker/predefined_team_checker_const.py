APP_ID="predefined_team_checker"
APP_NAME="预备编队角色识别"