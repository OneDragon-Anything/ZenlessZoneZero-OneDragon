APP_ID="mouse_sensitivity_checker"
APP_NAME="鼠标灵敏度检测"