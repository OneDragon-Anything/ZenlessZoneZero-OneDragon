APP_ID="screenshot_helper"
APP_NAME="闪避截图"