APP_ID='notorious_hunt'
APP_NAME='恶名狩猎'
NEED_NOTIFY=True
