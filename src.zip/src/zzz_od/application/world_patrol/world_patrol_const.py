APP_ID="world_patrol"
APP_NAME="锄大地"
NEED_NOTIFY=True
