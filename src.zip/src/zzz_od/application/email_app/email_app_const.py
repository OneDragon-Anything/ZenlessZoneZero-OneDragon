APP_ID="email"
APP_NAME="邮件"
NEED_NOTIFY=True
