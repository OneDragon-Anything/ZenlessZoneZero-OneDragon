APP_ID="charge_plan"
APP_NAME="体力刷本"
NEED_NOTIFY=True
