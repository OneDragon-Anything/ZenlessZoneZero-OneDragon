DEFAULT_GROUP_ID = "one_dragon"
ONE_DRAGON_APP_ID = "one_dragon"
ONE_DRAGON_APP_NAME = "一条龙"